package controlstatement;

public class Simpleforloop {
	public static void main(String[] args) {
		//code for loop
		int i;
		for(i=1;i<=10;i++)//iteration ten times
		{
			System.out.println("the output is:"+i);
			
		}
	}

}
