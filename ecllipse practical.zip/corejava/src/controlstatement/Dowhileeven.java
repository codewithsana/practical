package controlstatement;

public class Dowhileeven {
public static void main(String[] args) {
	int i=1;
	System.out.println("first 10 even number\n");
	do {
		System.out.println(i);
		i=i+2;
	}while(i<=10);
}
}
