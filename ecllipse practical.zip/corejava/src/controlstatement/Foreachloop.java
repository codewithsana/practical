package controlstatement;

public class Foreachloop {
public static void main(String[] args) {
	int arr[]= {12,24,45,25,32};
	for(int i:arr)
	{
		System.out.println(i);
	}
}
}
