package controlstatement;

public class Whileloop {
	public static void main(String[] args) {
		int i=1;
		while(i<=10)
		{
			while(true) {
			System.out.println("chalte rho");
			i++;
		}
		
	}

}}
