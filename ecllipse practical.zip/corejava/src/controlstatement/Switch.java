package controlstatement;

public class Switch {
public static void main(String args[])
{
	int n01=10;//declare variable for switch
	switch(n01)//switch expression
	{
	case 1://case statement
		System.out.println("20");
		break;
	case 10:
		System.out.println("10");
		break;
	case 3:
		System.out.println("10");
		break;
	case 4:
		System.out.println("50");
		break;
	case 5:
		System.out.println("60");
		break;
		default:System.out.println("invalid number");//syso
	}
}
}
